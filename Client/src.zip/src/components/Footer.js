import React from 'react';

function Footer() {
  return (
    <footer className="text-center text-lg-start mt-4">
      
      <div className="text-center p-3"  style={{ color: 'white'}}>
        CSE416
      </div>
    </footer>
  );
}

export default Footer;
