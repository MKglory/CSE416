import './stylesheets/App.css';
import Root from './components/Root.js';

function App() {
  return (
    <div className="App">
      <Root />
    </div>
  );
}

export default App;
